from flask import Flask, render_template, redirect
from data import db_session
from data.users import User
from data.jobs import Jobs
from datetime import datetime
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from data.db_session import global_init, create_session
from forms.user import RegisterForm, LoginForm
from forms.add_job import AddJobForm
from data.jobs import Jobs

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)


@app.route('/job',  methods=['GET', 'POST'])
@login_required
def add_job():
    form = AddJobForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        job = Jobs()
        job.team_leader = form.team_leader.data
        job.job = form.job.data
        job.work_size = form.work_size.data
        job.collaborators = form.collaborators.data
        job.is_finished = form.is_finished.data
        db_sess.add(job)
        db_sess.commit()
        return redirect('/')
    return render_template('job.html', title='Adding a Job',
                           form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route('/')
@app.route('/index')
def index():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    return render_template('index.html', jobs=jobs)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            email=form.email.data,
            name=form.name.data,
            surname=form.surname.data,
            age=form.age.data,
            position=form.position.data,
            speciality=form.speciality.data,
            address=form.address.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


def create_users():
    db_sess = db_session.create_session()
    capitane = User()
    capitane.surname = 'Scott'
    capitane.name = 'Ridley'
    capitane.age = 21
    capitane.position = 'capitane'
    capitane.speciality = 'research engineer'
    capitane.address = 'module_1'
    capitane.email = 'scott_chief@mars.org'

    pilot = User()
    pilot.surname = 'Weir'
    pilot.name = 'Andy'
    pilot.age = 25
    pilot.position = 'pilot'
    pilot.speciality = 'pilot'
    pilot.address = 'module_2'
    pilot.email = 'weir@mars.org'

    builder = User()
    builder.surname = 'Watney'
    builder.name = 'Mark'
    builder.age = 22
    builder.position = 'builder'
    builder.speciality = 'builder'
    builder.address = 'module_3'
    builder.email = 'watney@mars.org'

    biolog = User()
    biolog.surname = 'Sanders'
    biolog.name = 'Taddy'
    biolog.age = 18
    biolog.position = 'biolog'
    biolog.speciality = 'biolog'
    biolog.address = 'module_4'
    biolog.email = 'sanders@mars.org'

    db_sess = db_session.create_session()
    db_sess.add(capitane)
    db_sess.add(pilot)
    db_sess.add(builder)
    db_sess.add(biolog)
    db_sess.commit()


def add_job():
    job = Jobs()
    job.team_leader = 1
    job.job = 'job deployment of residential modules 1 and 2'
    job.work_size = 15
    job.collaborators = '2, 3'
    job.start_date = datetime.now()
    job.is_finished = False
    db_sess = db_session.create_session()
    db_sess.add(job)
    db_sess.commit()


def main():
    db_session.global_init("db/mars_explorer.db")
    app.run()

    '''
    для запросов:
    
    global_init(input())
    db_sess = create_session()
    for user in db_sess.query(User).filter(User.age < 18):
        print(f'<Colonist> {user.id} {user.surname} {user.name} {user.age} years')
    '''


if __name__ == '__main__':
    main()